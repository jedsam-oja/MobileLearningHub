import { Link, useLocation } from "wouter";
import { cn } from "@/lib/utils";
import { useState } from "react";
import {
  BarChart,
  BookOpen,
  FileText,
  GraduationCap,
  LineChart,
  Settings,
  Users,
  ChevronRight,
  Menu
} from "lucide-react";

const navigation = [
  { 
    name: "Dashboard", 
    icon: BarChart, 
    href: "/",
  },
  { 
    name: "Learning", 
    icon: BookOpen,
    items: [
      { name: "Tutorials", href: "/tutorials" },
      { name: "Study Notes", href: "/study-notes" },
      { name: "Study Materials", href: "/study-materials" },
      { name: "Practice", href: "/practice" },
    ]
  },
  { 
    name: "Analytics", 
    icon: LineChart, 
    href: "/analytics" 
  },
  { 
    name: "Collaboration",
    icon: Users,
    items: [
      { name: "Study Groups", href: "/study-groups" },
      { name: "Live Sessions", href: "/live-sessions" },
    ]
  },
  { 
    name: "Settings", 
    icon: Settings, 
    href: "/settings" 
  }
];

export default function SidebarNav() {
  const [location] = useLocation();
  const [expandedItems, setExpandedItems] = useState<string[]>([]);
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  const toggleExpand = (name: string) => {
    setExpandedItems(current => 
      current.includes(name) 
        ? current.filter(item => item !== name)
        : [...current, name]
    );
  };

  return (
    <>
      <div className={cn(
        "fixed inset-y-0 left-0 w-[280px] bg-card border-r transition-transform duration-300 z-40",
        "lg:translate-x-0",
        mobileMenuOpen ? "translate-x-0" : "-translate-x-full"
      )}>
        <div className="flex items-center gap-2 h-[70px] px-6 border-b">
          <GraduationCap className="h-8 w-8 text-primary" />
          <h1 className="text-xl font-semibold">OnlineJAcademy</h1>
        </div>

        <div className="p-4">
          <nav className="space-y-1">
            {navigation.map((item) => (
              <div key={item.name}>
                {item.href ? (
                  <Link href={item.href}>
                    <a
                      className={cn(
                        "flex items-center gap-3 px-4 py-3 text-sm font-medium rounded-md",
                        location === item.href
                          ? "bg-primary text-primary-foreground"
                          : "text-muted-foreground hover:bg-accent"
                      )}
                    >
                      <item.icon className="h-5 w-5" />
                      <span>{item.name}</span>
                    </a>
                  </Link>
                ) : (
                  <div className="space-y-1">
                    <button
                      onClick={() => toggleExpand(item.name)}
                      className="flex items-center justify-between w-full px-4 py-3 text-sm font-medium text-muted-foreground hover:bg-accent rounded-md"
                    >
                      <div className="flex items-center gap-3">
                        <item.icon className="h-5 w-5" />
                        <span>{item.name}</span>
                      </div>
                      <ChevronRight 
                        className={cn(
                          "h-4 w-4 transition-transform",
                          expandedItems.includes(item.name) && "transform rotate-90"
                        )} 
                      />
                    </button>
                    <div 
                      className={cn(
                        "pl-12 space-y-1 overflow-hidden transition-all",
                        expandedItems.includes(item.name) ? "max-h-40" : "max-h-0"
                      )}
                    >
                      {item.items?.map((subItem) => (
                        <Link key={subItem.name} href={subItem.href}>
                          <a
                            className={cn(
                              "block px-4 py-2 text-sm font-medium rounded-md",
                              location === subItem.href
                                ? "text-primary"
                                : "text-muted-foreground hover:text-primary"
                            )}
                          >
                            {subItem.name}
                          </a>
                        </Link>
                      ))}
                    </div>
                  </div>
                )}
              </div>
            ))}
          </nav>
        </div>
      </div>

      {/* Mobile menu button */}
      <button 
        onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
        className={cn(
          "fixed bottom-6 right-6 z-50 lg:hidden",
          "w-12 h-12 rounded-full bg-primary text-white",
          "flex items-center justify-center shadow-lg"
        )}
      >
        <Menu className="h-6 w-6" />
      </button>

      {/* Mobile menu overlay */}
      {mobileMenuOpen && (
        <div 
          className="fixed inset-0 bg-black/50 z-30 lg:hidden"
          onClick={() => setMobileMenuOpen(false)}
        />
      )}
    </>
  );
}