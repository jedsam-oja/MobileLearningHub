import { Link, useLocation } from "wouter";
import { cn } from "@/lib/utils";
import {
  BookOpen,
  Home,
  FileText,
  Brain,
  User,
  ChevronRight,
  MenuIcon,
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Sheet, SheetContent, SheetHeader, SheetTitle, SheetTrigger } from "@/components/ui/sheet";
import { useState } from "react";
import { useMobile } from "@/hooks/use-mobile";

type NavItem = {
  title: string;
  href: string;
  icon: React.ElementType;
};

const navItems: NavItem[] = [
  { title: "Dashboard", href: "/", icon: Home },
  { title: "Tutorials", href: "/tutorials", icon: BookOpen },
  { title: "Notes", href: "/notes", icon: FileText },
  { title: "Practice", href: "/practice", icon: Brain },
  { title: "Profile", href: "/profile", icon: User },
];

export function Sidebar() {
  const [location] = useLocation();
  const isMobile = useMobile();
  const [open, setOpen] = useState(false);

  const NavContent = () => (
    <div className="space-y-4 py-4">
      <div className="px-3 py-2">
        <h2 className="mb-2 px-4 text-lg font-semibold">Navigation</h2>
        <div className="space-y-1">
          {navItems.map((item) => (
            <Link key={item.href} href={item.href}>
              <Button
                variant={location === item.href ? "secondary" : "ghost"}
                className={cn(
                  "w-full justify-start",
                  location === item.href && "bg-secondary"
                )}
                onClick={() => setOpen(false)}
              >
                <item.icon className="mr-2 h-4 w-4" />
                {item.title}
                <ChevronRight
                  className={cn(
                    "ml-auto h-4 w-4 transition-transform",
                    location === item.href && "rotate-90"
                  )}
                />
              </Button>
            </Link>
          ))}
        </div>
      </div>
    </div>
  );

  if (isMobile) {
    return (
      <Sheet open={open} onOpenChange={setOpen}>
        <SheetTrigger asChild>
          <Button variant="ghost" size="icon" className="lg:hidden">
            <MenuIcon className="h-6 w-6" />
          </Button>
        </SheetTrigger>
        <SheetContent side="left" className="w-72">
          <SheetHeader>
            <SheetTitle>OnlineJAcademy Medical</SheetTitle>
          </SheetHeader>
          <NavContent />
        </SheetContent>
      </Sheet>
    );
  }

  return (
    <div className="hidden lg:block border-r bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60">
      <div className="h-screen w-72 fixed">
        <div className="space-y-4 py-4">
          <div className="px-6 py-2">
            <h1 className="text-xl font-bold">OnlineJAcademy Medical</h1>
          </div>
          <NavContent />
        </div>
      </div>
    </div>
  );
}
