import { Video } from "@shared/schema";
import { Card, CardContent, CardFooter, CardHeader } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { Clock, Play } from "lucide-react";
import { Link } from "wouter";

interface VideoCardProps {
  video: Video;
  progress?: number;
}

export function VideoCard({ video, progress = 0 }: VideoCardProps) {
  const formatDuration = (seconds: number) => {
    const minutes = Math.floor(seconds / 60);
    const remainingSeconds = seconds % 60;
    return `${minutes}:${remainingSeconds.toString().padStart(2, '0')}`;
  };

  return (
    <Link href={`/tutorials/${video.id}`}>
      <Card className="group cursor-pointer transition-all hover:shadow-lg">
        <CardHeader className="p-0">
          <div className="relative aspect-video overflow-hidden rounded-t-lg">
            <img
              src={video.thumbnailUrl}
              alt={video.title}
              className="object-cover w-full h-full transition-transform group-hover:scale-105"
            />
            <div className="absolute inset-0 bg-black/20 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center">
              <div className="rounded-full bg-white/90 p-3">
                <Play className="h-6 w-6 text-primary" />
              </div>
            </div>
            <Badge className="absolute top-2 left-2" variant="secondary">
              {video.category}
            </Badge>
          </div>
        </CardHeader>
        <CardContent className="p-4">
          <h3 className="font-semibold line-clamp-2 mb-2">{video.title}</h3>
          <p className="text-sm text-muted-foreground line-clamp-2 mb-2">
            {video.description}
          </p>
          <div className="flex items-center gap-2 text-sm text-muted-foreground">
            <Clock className="h-4 w-4" />
            {formatDuration(video.duration)}
          </div>
        </CardContent>
        <CardFooter className="p-4 pt-0">
          <div className="w-full space-y-1">
            <Progress value={progress} className="h-1" />
            <p className="text-xs text-muted-foreground text-right">
              {progress}% completed
            </p>
          </div>
        </CardFooter>
      </Card>
    </Link>
  );
}
