import { useState } from "react";
import { Question } from "@shared/schema";
import { Card, CardContent, CardFooter } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { Label } from "@/components/ui/label";
import { cn } from "@/lib/utils";

interface QuestionCardProps {
  question: Question;
  onAnswer: (answer: string) => void;
}

export default function QuestionCard({ question, onAnswer }: QuestionCardProps) {
  const [selectedAnswer, setSelectedAnswer] = useState<string | null>(null);
  const [hasSubmitted, setHasSubmitted] = useState(false);

  const handleSubmit = () => {
    if (!selectedAnswer) return;
    setHasSubmitted(true);
    onAnswer(selectedAnswer);
  };

  return (
    <Card>
      <CardContent className="p-6">
        <div className="mb-6">
          <span className="px-2 py-1 bg-primary/10 text-primary text-sm rounded">
            {question.category}
          </span>
          <span className="ml-2 px-2 py-1 bg-accent text-accent-foreground text-sm rounded">
            {question.difficulty}
          </span>
        </div>

        <h3 className="text-lg font-semibold mb-4">{question.question}</h3>

        <RadioGroup
          value={selectedAnswer || ""}
          onValueChange={setSelectedAnswer}
          disabled={hasSubmitted}
        >
          <div className="space-y-3">
            {(question.options as string[]).map((option) => (
              <div
                key={option}
                className={cn(
                  "flex items-center border rounded-lg p-4",
                  hasSubmitted && option === question.correctAnswer && "bg-primary/10 border-primary",
                  hasSubmitted && selectedAnswer === option && option !== question.correctAnswer && "bg-destructive/10 border-destructive"
                )}
              >
                <RadioGroupItem value={option} id={option} />
                <Label htmlFor={option} className="flex-1 ml-3 cursor-pointer">
                  {option}
                </Label>
              </div>
            ))}
          </div>
        </RadioGroup>

        {hasSubmitted && (
          <div className="mt-4 p-4 bg-card border rounded-lg">
            <h4 className="font-semibold mb-2">Explanation</h4>
            <p className="text-muted-foreground">{question.explanation}</p>
          </div>
        )}
      </CardContent>

      <CardFooter className="p-6 pt-0">
        <Button 
          className="w-full"
          onClick={handleSubmit}
          disabled={!selectedAnswer || hasSubmitted}
        >
          Submit Answer
        </Button>
      </CardFooter>
    </Card>
  );
}
