import { Tutorial } from "@shared/schema";
import { Card, CardContent, CardFooter } from "@/components/ui/card";
import { Progress } from "@/components/ui/progress";
import { PlayCircle, Clock, User } from "lucide-react";
import { Button } from "@/components/ui/button";

interface TutorialCardProps {
  tutorial: Tutorial;
  progress?: number;
  onWatch?: (id: number) => void;
}

export default function TutorialCard({ tutorial, progress = 0, onWatch }: TutorialCardProps) {
  const formatDuration = (minutes: number) => {
    const hrs = Math.floor(minutes / 60);
    const mins = minutes % 60;
    return `${hrs > 0 ? `${hrs}h ` : ''}${mins}m`;
  };

  return (
    <Card className="overflow-hidden">
      <div className="relative aspect-video">
        <img 
          src={tutorial.thumbnailUrl} 
          alt={tutorial.title}
          className="object-cover w-full h-full"
        />
        <div className="absolute inset-0 bg-black/40 flex items-center justify-center opacity-0 hover:opacity-100 transition-opacity">
          <Button
            variant="secondary"
            className="gap-2"
            onClick={() => onWatch?.(tutorial.id)}
          >
            <PlayCircle className="h-5 w-5" />
            Watch Now
          </Button>
        </div>
        <span className="absolute top-2 left-2 px-2 py-1 bg-primary text-primary-foreground text-xs rounded">
          {tutorial.category}
        </span>
      </div>

      <CardContent className="p-4">
        <h3 className="font-semibold mb-2 line-clamp-2">{tutorial.title}</h3>
        <p className="text-sm text-muted-foreground line-clamp-2 mb-4">
          {tutorial.description}
        </p>
        
        <div className="flex items-center gap-4 text-sm text-muted-foreground">
          <div className="flex items-center gap-1">
            <Clock className="h-4 w-4" />
            {formatDuration(tutorial.duration)}
          </div>
          <div className="flex items-center gap-1">
            <User className="h-4 w-4" />
            {tutorial.instructor}
          </div>
        </div>
      </CardContent>

      <CardFooter className="p-4 pt-0">
        <div className="w-full">
          <div className="flex justify-between text-sm mb-1">
            <span>Progress</span>
            <span>{progress}%</span>
          </div>
          <Progress value={progress} className="h-2" />
        </div>
      </CardFooter>
    </Card>
  );
}
