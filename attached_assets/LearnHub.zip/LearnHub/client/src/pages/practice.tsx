import { Header } from "@/components/layout/header";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Progress } from "@/components/ui/progress";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { useQuery, useMutation } from "@tanstack/react-query";
import { Quiz, Question, QuizResult } from "@shared/schema";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { useState } from "react";
import { Brain, Check, ChevronRight, Timer } from "lucide-react";
import { useToast } from "@/hooks/use-toast";

export default function Practice() {
  const { toast } = useToast();
  const [activeQuiz, setActiveQuiz] = useState<Quiz | null>(null);
  const [currentQuestionIndex, setCurrentQuestionIndex] = useState(0);
  const [selectedAnswers, setSelectedAnswers] = useState<string[]>([]);

  const { data: quizzes } = useQuery<Quiz[]>({
    queryKey: ["/api/quizzes"],
  });

  const { data: questions } = useQuery<Question[]>({
    queryKey: ["/api/quizzes", activeQuiz?.id, "questions"],
    enabled: !!activeQuiz,
  });

  const submitQuizMutation = useMutation({
    mutationFn: async (data: { quizId: number; score: number; totalQuestions: number }) => {
      const res = await apiRequest("POST", "/api/quiz-results", data);
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/quiz-results"] });
      toast({ title: "Quiz completed!" });
      setActiveQuiz(null);
      setCurrentQuestionIndex(0);
      setSelectedAnswers([]);
    },
    onError: (error: Error) => {
      toast({
        title: "Failed to submit quiz",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  const currentQuestion = questions?.[currentQuestionIndex];

  const handleAnswer = (answer: string) => {
    const newAnswers = [...selectedAnswers];
    newAnswers[currentQuestionIndex] = answer;
    setSelectedAnswers(newAnswers);
  };

  const handleNext = () => {
    if (!questions) return;
    
    if (currentQuestionIndex === questions.length - 1) {
      // Calculate score
      const correctAnswers = selectedAnswers.reduce((acc, answer, index) => {
        return acc + (answer === questions[index].correctAnswer ? 1 : 0);
      }, 0);

      submitQuizMutation.mutate({
        quizId: activeQuiz!.id,
        score: correctAnswers,
        totalQuestions: questions.length,
      });
    } else {
      setCurrentQuestionIndex(currentQuestionIndex + 1);
    }
  };

  return (
    <div className="min-h-screen">
      <Header />
      <main className="container py-6 lg:py-8">
        <div className="flex flex-col gap-8">
          {/* Page Header */}
          <div>
            <h1 className="text-3xl font-bold tracking-tight">Practice Questions</h1>
            <p className="text-muted-foreground">Test your medical knowledge</p>
          </div>

          {!activeQuiz ? (
            // Quiz Selection
            <div className="grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
              {quizzes?.map((quiz) => (
                <Card key={quiz.id} className="cursor-pointer hover:bg-accent/5" onClick={() => setActiveQuiz(quiz)}>
                  <CardHeader>
                    <CardTitle className="flex items-center gap-2">
                      <Brain className="h-5 w-5 text-primary" />
                      {quiz.title}
                    </CardTitle>
                    <CardDescription>{quiz.description}</CardDescription>
                  </CardHeader>
                  <CardContent>
                    <div className="flex items-center gap-2 text-sm text-muted-foreground">
                      <Timer className="h-4 w-4" />
                      <span>20 minutes</span>
                    </div>
                  </CardContent>
                  <CardFooter>
                    <Button className="w-full">
                      Start Quiz
                      <ChevronRight className="ml-2 h-4 w-4" />
                    </Button>
                  </CardFooter>
                </Card>
              ))}
            </div>
          ) : (
            // Quiz Interface
            <Card className="max-w-2xl mx-auto">
              <CardHeader>
                <CardTitle>{activeQuiz.title}</CardTitle>
                <Progress 
                  value={(currentQuestionIndex + 1) / (questions?.length || 1) * 100} 
                  className="mt-2"
                />
                <p className="text-sm text-muted-foreground mt-2">
                  Question {currentQuestionIndex + 1} of {questions?.length}
                </p>
              </CardHeader>
              <CardContent className="space-y-6">
                {currentQuestion && (
                  <>
                    <div className="text-lg font-medium">{currentQuestion.question}</div>
                    <RadioGroup
                      value={selectedAnswers[currentQuestionIndex]}
                      onValueChange={handleAnswer}
                    >
                      {currentQuestion.options.map((option, index) => (
                        <div key={index} className="flex items-center space-x-2">
                          <RadioGroupItem value={option} id={`option-${index}`} />
                          <label
                            htmlFor={`option-${index}`}
                            className="text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70"
                          >
                            {option}
                          </label>
                        </div>
                      ))}
                    </RadioGroup>
                  </>
                )}
              </CardContent>
              <CardFooter>
                <Button
                  className="w-full"
                  onClick={handleNext}
                  disabled={!selectedAnswers[currentQuestionIndex]}
                >
                  {currentQuestionIndex === (questions?.length || 0) - 1 ? (
                    <>
                      Submit Quiz
                      <Check className="ml-2 h-4 w-4" />
                    </>
                  ) : (
                    <>
                      Next Question
                      <ChevronRight className="ml-2 h-4 w-4" />
                    </>
                  )}
                </Button>
              </CardFooter>
            </Card>
          )}
        </div>
      </main>
    </div>
  );
}
