import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { Tutorial } from "@shared/schema";
import Header from "@/components/layout/header";
import SidebarNav from "@/components/layout/sidebar-nav";
import TutorialCard from "@/components/tutorial/tutorial-card";
import { Loader2 } from "lucide-react";
import { Button } from "@/components/ui/button";

const categories = ["All", "Clinical", "Basic Sciences", "Procedures", "Cases"];

export default function TutorialsPage() {
  const [selectedCategory, setSelectedCategory] = useState("All");

  const { data: tutorials, isLoading } = useQuery<Tutorial[]>({
    queryKey: ["/api/tutorials"]
  });

  const filteredTutorials = tutorials?.filter(
    tutorial => selectedCategory === "All" || tutorial.category === selectedCategory
  );

  if (isLoading) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <Loader2 className="h-8 w-8 animate-spin text-primary" />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background">
      <SidebarNav />
      <Header />

      <main className="ml-[280px] pt-[70px] p-6">
        <div className="mb-8">
          <h1 className="text-3xl font-bold mb-4">Video Tutorials</h1>
          <p className="text-muted-foreground mb-6">
            Browse our comprehensive collection of medical video tutorials.
          </p>

          <div className="flex gap-2 flex-wrap">
            {categories.map(category => (
              <Button
                key={category}
                variant={selectedCategory === category ? "default" : "outline"}
                onClick={() => setSelectedCategory(category)}
              >
                {category}
              </Button>
            ))}
          </div>
        </div>

        <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
          {filteredTutorials?.map(tutorial => (
            <TutorialCard
              key={tutorial.id}
              tutorial={tutorial}
              onWatch={(id) => {
                // Handle video playback
                console.log("Watch tutorial:", id);
              }}
            />
          ))}
        </div>
      </main>
    </div>
  );
}
