import { Header } from "@/components/layout/header";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { useAuth } from "@/hooks/use-auth";
import { useQuery } from "@tanstack/react-query";
import { VideoCard } from "@/components/video/video-card";
import { Progress } from "@/components/ui/progress";
import { Link } from "wouter";
import { Video, Progress as UserProgress, QuizResult } from "@shared/schema";
import { BookOpen, Brain, Clock, Medal, PlayCircle, Target } from "lucide-react";

export default function Dashboard() {
  const { user } = useAuth();

  const { data: videos } = useQuery<Video[]>({
    queryKey: ["/api/videos"],
  });

  const { data: progress } = useQuery<UserProgress[]>({
    queryKey: ["/api/progress"],
  });

  const { data: quizResults } = useQuery<QuizResult[]>({
    queryKey: ["/api/quiz-results"],
  });

  const recentVideos = videos?.slice(0, 3) || [];
  const totalWatchTime = progress?.reduce((acc, curr) => acc + curr.watchedDuration, 0) || 0;
  const completedVideos = progress?.filter(p => p.completed).length || 0;
  const averageScore = quizResults?.reduce((acc, curr) => acc + (curr.score / curr.totalQuestions * 100), 0) || 0;
  const quizCount = quizResults?.length || 0;

  return (
    <div className="min-h-screen">
      <Header />
      <main className="container py-6 lg:py-8">
        <div className="flex flex-col gap-8">
          {/* Welcome Section */}
          <div>
            <h1 className="text-3xl font-bold tracking-tight">Welcome back, {user?.name}!</h1>
            <p className="text-muted-foreground">Track your progress and continue your medical studies.</p>
          </div>

          {/* Stats Grid */}
          <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
            <Card>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">Watch Time</CardTitle>
                <Clock className="h-4 w-4 text-muted-foreground" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">{Math.round(totalWatchTime / 60)} mins</div>
                <p className="text-xs text-muted-foreground">Total time spent learning</p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">Completed</CardTitle>
                <Target className="h-4 w-4 text-muted-foreground" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">{completedVideos}</div>
                <p className="text-xs text-muted-foreground">Videos completed</p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">Quiz Score</CardTitle>
                <Medal className="h-4 w-4 text-muted-foreground" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">{quizCount ? Math.round(averageScore / quizCount) : 0}%</div>
                <p className="text-xs text-muted-foreground">Average quiz performance</p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">Quizzes Taken</CardTitle>
                <Brain className="h-4 w-4 text-muted-foreground" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">{quizCount}</div>
                <p className="text-xs text-muted-foreground">Total assessments completed</p>
              </CardContent>
            </Card>
          </div>

          {/* Continue Learning */}
          <Card>
            <CardHeader>
              <CardTitle>Continue Learning</CardTitle>
              <CardDescription>Pick up where you left off</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
                {recentVideos.map((video) => (
                  <VideoCard
                    key={video.id}
                    video={video}
                    progress={
                      progress?.find((p) => p.videoId === video.id)?.watchedDuration
                        ? (progress?.find((p) => p.videoId === video.id)?.watchedDuration! / video.duration) * 100
                        : 0
                    }
                  />
                ))}
              </div>
            </CardContent>
          </Card>

          {/* Quick Actions */}
          <div className="grid gap-4 md:grid-cols-3">
            <Link href="/tutorials">
              <Card className="cursor-pointer hover:bg-accent">
                <CardContent className="flex items-center gap-4 pt-6">
                  <PlayCircle className="h-8 w-8 text-primary" />
                  <div>
                    <h3 className="font-semibold">Browse Tutorials</h3>
                    <p className="text-sm text-muted-foreground">Access all medical lectures</p>
                  </div>
                </CardContent>
              </Card>
            </Link>

            <Link href="/notes">
              <Card className="cursor-pointer hover:bg-accent">
                <CardContent className="flex items-center gap-4 pt-6">
                  <BookOpen className="h-8 w-8 text-primary" />
                  <div>
                    <h3 className="font-semibold">Study Notes</h3>
                    <p className="text-sm text-muted-foreground">Review your notes</p>
                  </div>
                </CardContent>
              </Card>
            </Link>

            <Link href="/practice">
              <Card className="cursor-pointer hover:bg-accent">
                <CardContent className="flex items-center gap-4 pt-6">
                  <Brain className="h-8 w-8 text-primary" />
                  <div>
                    <h3 className="font-semibold">Practice Questions</h3>
                    <p className="text-sm text-muted-foreground">Test your knowledge</p>
                  </div>
                </CardContent>
              </Card>
            </Link>
          </div>
        </div>
      </main>
    </div>
  );
}
