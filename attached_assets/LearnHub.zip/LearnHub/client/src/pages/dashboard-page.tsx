import { useQuery } from "@tanstack/react-query";
import { useAuth } from "@/hooks/use-auth";
import { Progress, Tutorial } from "@shared/schema";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import Header from "@/components/layout/header";
import SidebarNav from "@/components/layout/sidebar-nav";
import { 
  Loader2, 
  BookOpen, 
  Users, 
  Clock, 
  BarChart,
  ChevronRight,
  Play
} from "lucide-react";
import { Button } from "@/components/ui/button";

export default function DashboardPage() {
  const { user } = useAuth();
  const { data: tutorials, isLoading: tutorialsLoading } = useQuery<Tutorial[]>({
    queryKey: ["/api/tutorials"]
  });

  const { data: progress, isLoading: progressLoading } = useQuery<Progress[]>({
    queryKey: ["/api/progress"]
  });

  if (tutorialsLoading || progressLoading) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <Loader2 className="h-8 w-8 animate-spin text-primary" />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background">
      <SidebarNav />
      <Header />

      <main className="ml-[280px] pt-[70px] p-6">
        <div className="welcome-card">
          <div className="welcome-content">
            <h1 className="welcome-title">Welcome back, {user?.username}! 👋</h1>
            <p className="welcome-subtitle">
              Track your progress and continue your medical education journey
            </p>
            <div className="welcome-progress">
              <div className="progress-info">
                <span>Overall Progress</span>
                <span>65%</span>
              </div>
              <div className="progress-bar">
                <div className="progress-value" style={{ width: '65%' }} />
              </div>
            </div>
          </div>
        </div>

        <div className="stats-row">
          <Card className="stat-card">
            <CardContent className="p-6">
              <div className="stat-icon bg-blue-100 text-blue-600">
                <BookOpen className="h-6 w-6" />
              </div>
              <div className="stat-value text-blue-600">24</div>
              <div className="stat-label">Active Courses</div>
            </CardContent>
          </Card>

          <Card className="stat-card">
            <CardContent className="p-6">
              <div className="stat-icon bg-green-100 text-green-600">
                <Users className="h-6 w-6" />
              </div>
              <div className="stat-value text-green-600">12</div>
              <div className="stat-label">Study Groups</div>
            </CardContent>
          </Card>

          <Card className="stat-card">
            <CardContent className="p-6">
              <div className="stat-icon bg-purple-100 text-purple-600">
                <Clock className="h-6 w-6" />
              </div>
              <div className="stat-value text-purple-600">48h</div>
              <div className="stat-label">Study Time</div>
            </CardContent>
          </Card>

          <Card className="stat-card">
            <CardContent className="p-6">
              <div className="stat-icon bg-orange-100 text-orange-600">
                <BarChart className="h-6 w-6" />
              </div>
              <div className="stat-value text-orange-600">89%</div>
              <div className="stat-label">Success Rate</div>
            </CardContent>
          </Card>
        </div>

        <div className="grid gap-6 md:grid-cols-2">
          <Card className="card-section">
            <div className="section-header">
              <h2 className="section-title">Continue Learning</h2>
              <Button variant="link" className="section-action">
                View All <ChevronRight className="h-4 w-4" />
              </Button>
            </div>
            <div className="space-y-4">
              {tutorials?.slice(0, 3).map(tutorial => (
                <div key={tutorial.id} className="course-card">
                  <div className="course-image">
                    <img src={tutorial.thumbnailUrl} alt={tutorial.title} />
                  </div>
                  <div className="course-details">
                    <h3 className="course-title">{tutorial.title}</h3>
                    <div className="course-info">
                      <span className="course-info-item">
                        <Clock className="h-4 w-4" />
                        2h 30m
                      </span>
                      <span className="course-info-item">
                        <BookOpen className="h-4 w-4" />
                        12 Lessons
                      </span>
                    </div>
                    <div className="course-progress">
                      <div 
                        className="course-progress-value" 
                        style={{ width: '60%' }} 
                      />
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </Card>

          <Card className="card-section">
            <div className="section-header">
              <h2 className="section-title">Upcoming Sessions</h2>
              <Button variant="link" className="section-action">
                View All <ChevronRight className="h-4 w-4" />
              </Button>
            </div>
            <div className="space-y-4">
              <div className="upcoming-session">
                <div className="session-date">
                  <div className="session-day">15</div>
                  <div className="session-month">Mar</div>
                </div>
                <div className="session-details">
                  <h3 className="session-title">Cardiology Group Study</h3>
                  <div className="session-info">
                    <span>2:00 PM EST</span>
                    <span>•</span>
                    <span>45 minutes</span>
                  </div>
                </div>
                <div className="session-action">
                  <Play className="h-4 w-4" />
                </div>
              </div>

              <div className="upcoming-session">
                <div className="session-date">
                  <div className="session-day">16</div>
                  <div className="session-month">Mar</div>
                </div>
                <div className="session-details">
                  <h3 className="session-title">USMLE Step 1 Review</h3>
                  <div className="session-info">
                    <span>10:00 AM EST</span>
                    <span>•</span>
                    <span>2 hours</span>
                  </div>
                </div>
                <div className="session-action">
                  <Play className="h-4 w-4" />
                </div>
              </div>
            </div>
          </Card>
        </div>
      </main>
    </div>
  );
}