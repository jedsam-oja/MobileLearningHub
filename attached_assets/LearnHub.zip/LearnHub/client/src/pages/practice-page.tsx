import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { Question } from "@shared/schema";
import Header from "@/components/layout/header";
import SidebarNav from "@/components/layout/sidebar-nav";
import QuestionCard from "@/components/practice/question-card";
import { Button } from "@/components/ui/button";
import { Progress } from "@/components/ui/progress";
import { Loader2 } from "lucide-react";

export default function PracticePage() {
  const [currentQuestionIndex, setCurrentQuestionIndex] = useState(0);
  const [answers, setAnswers] = useState<Record<number, string>>({});

  const { data: questions, isLoading } = useQuery<Question[]>({
    queryKey: ["/api/questions"]
  });

  const handleAnswer = (answer: string) => {
    setAnswers(prev => ({
      ...prev,
      [currentQuestionIndex]: answer
    }));
  };

  const calculateScore = () => {
    if (!questions) return 0;
    const correctAnswers = Object.entries(answers).filter(
      ([index, answer]) => answer === questions[parseInt(index)].correctAnswer
    ).length;
    return Math.round((correctAnswers / questions.length) * 100);
  };

  if (isLoading) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <Loader2 className="h-8 w-8 animate-spin text-primary" />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background">
      <SidebarNav />
      <Header />

      <main className="ml-[280px] pt-[70px] p-6">
        <div className="mb-8">
          <h1 className="text-3xl font-bold mb-4">Practice Questions</h1>
          <p className="text-muted-foreground mb-6">
            Test your knowledge with our practice questions.
          </p>

          <div className="max-w-3xl mx-auto">
            <div className="mb-6">
              <div className="flex justify-between text-sm mb-2">
                <span>Question {currentQuestionIndex + 1} of {questions?.length}</span>
                <span>Score: {calculateScore()}%</span>
              </div>
              <Progress 
                value={((currentQuestionIndex + 1) / (questions?.length || 1)) * 100} 
                className="h-2"
              />
            </div>

            {questions && questions[currentQuestionIndex] && (
              <QuestionCard
                question={questions[currentQuestionIndex]}
                onAnswer={handleAnswer}
              />
            )}

            <div className="flex justify-between mt-6">
              <Button
                variant="outline"
                disabled={currentQuestionIndex === 0}
                onClick={() => setCurrentQuestionIndex(prev => prev - 1)}
              >
                Previous
              </Button>
              <Button
                disabled={currentQuestionIndex === (questions?.length || 0) - 1}
                onClick={() => setCurrentQuestionIndex(prev => prev + 1)}
              >
                Next
              </Button>
            </div>
          </div>
        </div>
      </main>
    </div>
  );
}
