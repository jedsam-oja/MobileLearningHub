import { Header } from "@/components/layout/header";
import { VideoCard } from "@/components/video/video-card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { useQuery } from "@tanstack/react-query";
import { Video, Progress } from "@shared/schema";
import { Filter, Search } from "lucide-react";
import { useState } from "react";

export default function Tutorials() {
  const [search, setSearch] = useState("");
  const [selectedCategory, setSelectedCategory] = useState<string | null>(null);

  const { data: videos } = useQuery<Video[]>({
    queryKey: ["/api/videos"],
  });

  const { data: progress } = useQuery<Progress[]>({
    queryKey: ["/api/progress"],
  });

  const categories = videos
    ? Array.from(new Set(videos.map((video) => video.category)))
    : [];

  const filteredVideos = videos?.filter((video) => {
    const matchesSearch = video.title.toLowerCase().includes(search.toLowerCase()) ||
                         video.description.toLowerCase().includes(search.toLowerCase());
    const matchesCategory = !selectedCategory || video.category === selectedCategory;
    return matchesSearch && matchesCategory;
  });

  return (
    <div className="min-h-screen">
      <Header />
      <main className="container py-6 lg:py-8">
        <div className="flex flex-col gap-8">
          {/* Page Header */}
          <div>
            <h1 className="text-3xl font-bold tracking-tight">Medical Tutorials</h1>
            <p className="text-muted-foreground">
              Browse through our comprehensive collection of medical lectures
            </p>
          </div>

          {/* Search and Filters */}
          <Card className="p-4">
            <div className="flex flex-col gap-4 md:flex-row md:items-center md:justify-between">
              <div className="relative flex-1">
                <Search className="absolute left-2 top-2.5 h-4 w-4 text-muted-foreground" />
                <Input
                  placeholder="Search tutorials..."
                  className="pl-8"
                  value={search}
                  onChange={(e) => setSearch(e.target.value)}
                />
              </div>
              <div className="flex flex-wrap gap-2">
                <Button
                  variant={selectedCategory === null ? "secondary" : "outline"}
                  onClick={() => setSelectedCategory(null)}
                >
                  All
                </Button>
                {categories.map((category) => (
                  <Button
                    key={category}
                    variant={selectedCategory === category ? "secondary" : "outline"}
                    onClick={() => setSelectedCategory(category)}
                  >
                    {category}
                  </Button>
                ))}
              </div>
            </div>
          </Card>

          {/* Video Grid */}
          <div className="grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
            {filteredVideos?.map((video) => (
              <VideoCard
                key={video.id}
                video={video}
                progress={
                  progress?.find((p) => p.videoId === video.id)?.watchedDuration
                    ? (progress?.find((p) => p.videoId === video.id)?.watchedDuration! / video.duration) * 100
                    : 0
                }
              />
            ))}
          </div>

          {/* Empty State */}
          {filteredVideos?.length === 0 && (
            <div className="text-center py-12">
              <h3 className="text-lg font-semibold mb-2">No tutorials found</h3>
              <p className="text-muted-foreground">
                Try adjusting your search or filters to find what you're looking for
              </p>
            </div>
          )}
        </div>
      </main>
    </div>
  );
}
