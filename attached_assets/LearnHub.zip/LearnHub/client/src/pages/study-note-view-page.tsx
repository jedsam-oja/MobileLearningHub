import { useQuery } from "@tanstack/react-query";
import { useParams } from "wouter";
import Header from "@/components/layout/header";
import SidebarNav from "@/components/layout/sidebar-nav";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { BookOpen, Clock } from "lucide-react";
import { cn } from "@/lib/utils";

interface Note {
  id: number;
  title: string;
  category: string;
  content: string;
  progress: number;
  lastModified: string;
  sections: {
    id: number;
    title: string;
    completed: boolean;
    subsections?: {
      id: number;
      title: string;
      completed: boolean;
    }[];
  }[];
}

export default function StudyNoteViewPage() {
  const { id } = useParams();

  // This would normally come from an API call
  const note: Note = {
    id: parseInt(id || "1"),
    title: "Cardiovascular System",
    category: "Anatomy",
    content: "Note content goes here...",
    progress: 60,
    lastModified: "2 days ago",
    sections: [
      {
        id: 1,
        title: "Heart Anatomy",
        completed: true,
        subsections: [
          { id: 1, title: "Chambers", completed: true },
          { id: 2, title: "Valves", completed: true },
          { id: 3, title: "Blood Supply", completed: false }
        ]
      },
      {
        id: 2,
        title: "Blood Vessels",
        completed: false,
        subsections: [
          { id: 4, title: "Arteries", completed: false },
          { id: 5, title: "Veins", completed: false },
          { id: 6, title: "Capillaries", completed: false }
        ]
      },
      {
        id: 3,
        title: "Cardiac Cycle",
        completed: false,
        subsections: [
          { id: 7, title: "Systole", completed: false },
          { id: 8, title: "Diastole", completed: false }
        ]
      }
    ]
  };

  return (
    <div className="min-h-screen bg-background">
      <SidebarNav />
      <Header />

      <main className="lg:ml-[280px] pt-[70px]">
        <div className="notes-container">
          <div className="notes-content">
            <div className="notes-main">
              <div className="page-header">
                <div className="page-header-content">
                  <div>
                    <h1 className="text-3xl font-bold mb-2 text-white">{note.title}</h1>
                    <p className="text-white/80">{note.category}</p>
                  </div>

                  <Button className="bg-white text-primary hover:bg-white/90">
                    Continue Reading
                  </Button>
                </div>
              </div>

              <div className="mt-8">
                <Card className="p-6">
                  <h2 className="text-xl font-semibold mb-4">Introduction</h2>
                  <p className="text-muted-foreground">
                    The cardiovascular system is one of the most important systems in the human body, 
                    responsible for transporting oxygen, nutrients, and other essential substances 
                    throughout the body while removing waste products.
                  </p>
                </Card>
              </div>
            </div>

            <div className="notes-sidebar">
              <Card className="notes-navigation">
                <div className="notes-nav-header">
                  <h2 className="notes-nav-title">
                    <BookOpen className="h-5 w-5" />
                    <span>Contents</span>
                  </h2>
                </div>

                <div className="notes-nav-list">
                  {note.sections.map((section) => (
                    <div key={section.id}>
                      <div className={cn(
                        "notes-nav-item",
                        section.completed && "completed"
                      )}>
                        <span className="notes-nav-text">{section.title}</span>
                        <div className={cn(
                          "notes-progress",
                          section.completed && "completed"
                        )}>
                          {section.completed ? "✓" : "0%"}
                        </div>
                      </div>

                      {section.subsections && (
                        <div className="notes-subnav">
                          {section.subsections.map((subsection) => (
                            <div 
                              key={subsection.id}
                              className={cn(
                                "notes-subnav-item",
                                subsection.completed && "completed"
                              )}
                            >
                              <span className="notes-subnav-text">
                                {subsection.title}
                              </span>
                              <div className={cn(
                                "notes-progress",
                                subsection.completed && "completed"
                              )}>
                                {subsection.completed ? "✓" : "0%"}
                              </div>
                            </div>
                          ))}
                        </div>
                      )}
                    </div>
                  ))}
                </div>
              </Card>
            </div>
          </div>
        </div>
      </main>
    </div>
  );
}