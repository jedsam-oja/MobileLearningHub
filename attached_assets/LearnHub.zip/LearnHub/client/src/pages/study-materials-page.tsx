import { useQuery } from "@tanstack/react-query";
import { StudyMaterial } from "@shared/schema";
import Header from "@/components/layout/header";
import SidebarNav from "@/components/layout/sidebar-nav";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Badge } from "@/components/ui/badge";
import { Loader2, FileText, Book, Star } from "lucide-react";

export default function StudyMaterialsPage() {
  const { data: materials, isLoading } = useQuery<StudyMaterial[]>({
    queryKey: ["/api/study-materials"]
  });

  if (isLoading) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <Loader2 className="h-8 w-8 animate-spin text-primary" />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background">
      <SidebarNav />
      <Header />

      <main className="ml-[280px] pt-[70px] p-6">
        <div className="mb-8">
          <h1 className="text-3xl font-bold mb-4">Study Materials</h1>
          <p className="text-muted-foreground">
            Access comprehensive study notes and references.
          </p>
        </div>

        <div className="grid gap-6 md:grid-cols-2">
          {materials?.map(material => (
            <Card key={material.id} className="overflow-hidden">
              <CardHeader className="flex flex-row items-center gap-4 pb-2">
                <div className="h-12 w-12 rounded-lg bg-primary/10 flex items-center justify-center">
                  {material.category === "Notes" ? (
                    <FileText className="h-6 w-6 text-primary" />
                  ) : material.category === "Reference" ? (
                    <Book className="h-6 w-6 text-primary" />
                  ) : (
                    <Star className="h-6 w-6 text-primary" />
                  )}
                </div>
                <div className="flex-1">
                  <CardTitle className="flex items-center gap-2">
                    {material.title}
                    <Badge variant="outline">{material.category}</Badge>
                  </CardTitle>
                </div>
              </CardHeader>
              <CardContent>
                <ScrollArea className="h-[200px] w-full rounded-md border p-4">
                  <div className="prose prose-sm dark:prose-invert">
                    {material.content}
                  </div>
                </ScrollArea>
              </CardContent>
            </Card>
          ))}
        </div>
      </main>
    </div>
  );
}
