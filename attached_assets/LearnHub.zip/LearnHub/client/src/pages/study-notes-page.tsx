import { useQuery } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import Header from "@/components/layout/header";
import SidebarNav from "@/components/layout/sidebar-nav";
import { Link } from "wouter";
import {
  Filter,
  Plus,
  Search,
  BookOpen,
  Clock,
  ChevronRight
} from "lucide-react";
import cn from 'classnames';

interface Note {
  id: number;
  title: string;
  category: string;
  lastModified: string;
  progress: number;
  totalPages: number;
  status: "not-started" | "in-progress" | "completed";
}

export default function StudyNotesPage() {
  const { data: notes, isLoading } = useQuery<Note[]>({
    queryKey: ["/api/study-notes"]
  });

  const templateNotes: Note[] = [
    {
      id: 1,
      title: "Cardiovascular System",
      category: "Anatomy",
      lastModified: "2 days ago",
      progress: 60,
      totalPages: 5,
      status: "in-progress"
    },
    {
      id: 2,
      title: "Respiratory System",
      category: "Physiology",
      lastModified: "1 week ago",
      progress: 100,
      totalPages: 3,
      status: "completed"
    },
    {
      id: 3,
      title: "Neurology Basics",
      category: "Clinical",
      lastModified: "3 days ago",
      progress: 75,
      totalPages: 8,
      status: "in-progress"
    },
    {
      id: 4,
      title: "Endocrine System",
      category: "Physiology",
      lastModified: "5 days ago",
      progress: 30,
      totalPages: 6,
      status: "in-progress"
    },
    {
      id: 5,
      title: "Gastrointestinal Tract",
      category: "Anatomy",
      lastModified: "1 day ago",
      progress: 0,
      totalPages: 4,
      status: "not-started"
    },
    {
      id: 6,
      title: "Musculoskeletal System",
      category: "Anatomy",
      lastModified: "4 days ago",
      progress: 100,
      totalPages: 7,
      status: "completed"
    }
  ];

  return (
    <div className="min-h-screen bg-background">
      <SidebarNav />
      <Header />

      <main className="lg:ml-[280px] pt-[70px] p-6">
        <div className="page-header">
          <div className="page-header-content">
            <div>
              <h1 className="text-3xl font-bold mb-2 text-white">Study Notes</h1>
              <p className="text-white/80">
                Manage and organize your medical study notes
              </p>
            </div>

            <div className="flex gap-4">
              <Button className="bg-white text-primary hover:bg-white/90 flex items-center gap-2">
                <Plus className="h-4 w-4" />
                New Note
              </Button>
              <Button variant="outline" className="bg-white/10 text-white border-white/20 hover:bg-white/20">
                <Filter className="h-4 w-4" />
              </Button>
            </div>
          </div>
        </div>

        <div className="search-filter-container mb-8">
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
            <div className="filter-item">
              <div className="relative">
                <input
                  type="text"
                  placeholder="Search notes..."
                  className="w-full h-10 pl-10 pr-4 rounded-md border border-border bg-background"
                />
                <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
              </div>
            </div>
            <div className="filter-item">
              <select className="w-full h-10 px-4 rounded-md border border-border bg-background">
                <option value="">All Categories</option>
                <option value="anatomy">Anatomy</option>
                <option value="physiology">Physiology</option>
                <option value="clinical">Clinical</option>
              </select>
            </div>
            <div className="filter-item">
              <select className="w-full h-10 px-4 rounded-md border border-border bg-background">
                <option value="">Status</option>
                <option value="not-started">Not Started</option>
                <option value="in-progress">In Progress</option>
                <option value="completed">Completed</option>
              </select>
            </div>
          </div>
        </div>

        <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
          {templateNotes.map((note) => (
            <Link key={note.id} href={`/study-notes/${note.id}`}>
              <Card className="group-card cursor-pointer">
                <div className="p-6">
                  <div className="flex items-start justify-between">
                    <div className="flex items-center gap-3">
                      <div className={cn(
                        "w-10 h-10 rounded-lg flex items-center justify-center",
                        note.status === "completed" ? "bg-green-100 text-green-600" :
                        note.status === "in-progress" ? "bg-blue-100 text-blue-600" :
                        "bg-gray-100 text-gray-600"
                      )}>
                        <BookOpen className="h-5 w-5" />
                      </div>
                      <div>
                        <h3 className="font-medium">{note.title}</h3>
                        <p className="text-sm text-muted-foreground">{note.category}</p>
                      </div>
                    </div>
                    <ChevronRight className="h-4 w-4 text-muted-foreground" />
                  </div>
                  <div className="mt-4">
                    <div className="flex justify-between text-sm text-muted-foreground mb-2">
                      <span>Progress</span>
                      <span>{note.progress}%</span>
                    </div>
                    <div className="h-1.5 bg-border rounded-full overflow-hidden">
                      <div 
                        className={cn(
                          "h-full rounded-full",
                          note.status === "completed" ? "bg-green-500" :
                          note.status === "in-progress" ? "bg-blue-500" :
                          "bg-gray-500"
                        )}
                        style={{ width: `${note.progress}%` }} 
                      />
                    </div>
                  </div>
                  <div className="mt-4 flex items-center gap-4 text-sm text-muted-foreground">
                    <div className="flex items-center gap-1">
                      <Clock className="h-4 w-4" />
                      <span>{note.lastModified}</span>
                    </div>
                    <div className="flex items-center gap-1">
                      <BookOpen className="h-4 w-4" />
                      <span>{note.totalPages} pages</span>
                    </div>
                  </div>
                </div>
              </Card>
            </Link>
          ))}
        </div>
      </main>
    </div>
  );
}