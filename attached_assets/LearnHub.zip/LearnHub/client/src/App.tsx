import { QueryClientProvider } from "@tanstack/react-query";
import { Switch, Route } from "wouter";
import { queryClient } from "./lib/queryClient";
import { Toaster } from "@/components/ui/toaster";
import { AuthProvider } from "@/hooks/use-auth";
import { ProtectedRoute } from "./lib/protected-route";

import NotFound from "@/pages/not-found";
import AuthPage from "@/pages/auth-page";
import DashboardPage from "@/pages/dashboard-page";
import TutorialsPage from "@/pages/tutorials-page";
import StudyNotesPage from "@/pages/study-notes-page";
import StudyNoteViewPage from "@/pages/study-note-view-page";
import StudyMaterialsPage from "@/pages/study-materials-page";
import PracticePage from "@/pages/practice-page";
import AnalyticsPage from "@/pages/analytics-page";
import StudyGroupsPage from "@/pages/study-groups-page";

function Router() {
  return (
    <Switch>
      <Route path="/auth" component={AuthPage} />
      <ProtectedRoute path="/" component={DashboardPage} />
      <ProtectedRoute path="/tutorials" component={TutorialsPage} />
      <ProtectedRoute path="/study-notes" component={StudyNotesPage} />
      <ProtectedRoute path="/study-notes/:id" component={StudyNoteViewPage} />
      <ProtectedRoute path="/study-materials" component={StudyMaterialsPage} />
      <ProtectedRoute path="/practice" component={PracticePage} />
      <ProtectedRoute path="/analytics" component={AnalyticsPage} />
      <ProtectedRoute path="/study-groups" component={StudyGroupsPage} />
      <Route component={NotFound} />
    </Switch>
  );
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <AuthProvider>
        <Router />
        <Toaster />
      </AuthProvider>
    </QueryClientProvider>
  );
}

export default App;