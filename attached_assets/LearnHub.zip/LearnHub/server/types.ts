import { 
  User, InsertUser, Tutorial, StudyMaterial, Question, Progress,
  QuizResult, ViewingStat, StudyStat, Achievement,
  StudyGroup, GroupMember, GroupDiscussion
} from "@shared/schema";
import { Store } from "express-session";

export interface IStorage {
  // User methods
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;

  // Tutorial methods
  getTutorials(): Promise<Tutorial[]>;
  getTutorial(id: number): Promise<Tutorial | undefined>;
  getTutorialsByCategory(category: string): Promise<Tutorial[]>;

  // Study materials methods
  getStudyMaterials(): Promise<StudyMaterial[]>;
  getStudyMaterial(id: number): Promise<StudyMaterial | undefined>;
  createStudyMaterial(material: Omit<StudyMaterial, "id">): Promise<StudyMaterial>;

  // Question methods
  getQuestions(): Promise<Question[]>;
  getQuestionsByCategory(category: string): Promise<Question[]>;

  // Progress methods
  getUserProgress(userId: number): Promise<Progress[]>;
  updateProgress(progress: Progress): Promise<Progress>;

  // Session store
  sessionStore: Store;

  // Analytics methods
  getQuizResults(userId: number): Promise<QuizResult[]>;
  saveQuizResult(result: Omit<QuizResult, "id">): Promise<QuizResult>;

  getViewingStats(userId: number, tutorialId?: number): Promise<ViewingStat[]>;
  updateViewingStats(stats: Omit<ViewingStat, "id">): Promise<ViewingStat>;

  getStudyStats(userId: number, materialId?: number): Promise<StudyStat[]>;
  updateStudyStats(stats: Omit<StudyStat, "id">): Promise<StudyStat>;

  getAchievements(userId: number): Promise<Achievement[]>;
  addAchievement(achievement: Omit<Achievement, "id">): Promise<Achievement>;

  // Analytics summaries
  getUserAnalyticsSummary(userId: number): Promise<{
    totalQuizzesTaken: number;
    averageScore: number;
    totalWatchTime: number;
    completedTutorials: number;
    achievementsCount: number;
  }>;

  // Study Groups methods
  createStudyGroup(group: Omit<StudyGroup, "id">): Promise<StudyGroup>;
  getStudyGroup(id: number): Promise<StudyGroup | undefined>;
  getStudyGroups(filter?: { category?: string }): Promise<StudyGroup[]>;
  getUserStudyGroups(userId: number): Promise<StudyGroup[]>;
  updateStudyGroup(id: number, data: Partial<StudyGroup>): Promise<StudyGroup>;

  // Group Members methods
  addGroupMember(member: Omit<GroupMember, "id">): Promise<GroupMember>;
  removeGroupMember(groupId: number, userId: number): Promise<void>;
  getGroupMembers(groupId: number): Promise<GroupMember[]>;
  getGroupMember(groupId: number, userId: number): Promise<GroupMember | undefined>;

  // Group Discussions methods
  addGroupDiscussion(discussion: Omit<GroupDiscussion, "id">): Promise<GroupDiscussion>;
  getGroupDiscussions(groupId: number, limit?: number): Promise<GroupDiscussion[]>;
  deleteGroupDiscussion(id: number): Promise<void>;
}