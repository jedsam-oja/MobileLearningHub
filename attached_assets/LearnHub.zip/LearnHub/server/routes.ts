import type { Express } from "express";
import { createServer, type Server } from "http";
import { setupAuth } from "./auth";
import { storage } from "./storage";
import { 
  insertProgressSchema, 
  insertQuizResultSchema,
  insertViewingStatsSchema,
  insertStudyStatsSchema,
  insertStudyGroupSchema,
  insertGroupMemberSchema,
  insertGroupDiscussionSchema
} from "@shared/schema";

export async function registerRoutes(app: Express): Promise<Server> {
  setupAuth(app);

  // Tutorials
  app.get("/api/tutorials", async (req, res) => {
    const tutorials = await storage.getTutorials();
    res.json(tutorials);
  });

  app.get("/api/tutorials/:id", async (req, res) => {
    const tutorial = await storage.getTutorial(parseInt(req.params.id));
    if (!tutorial) {
      return res.status(404).send("Tutorial not found");
    }
    res.json(tutorial);
  });

  app.get("/api/tutorials/category/:category", async (req, res) => {
    const tutorials = await storage.getTutorialsByCategory(req.params.category);
    res.json(tutorials);
  });

  // Study Materials
  app.get("/api/study-materials", async (req, res) => {
    const materials = await storage.getStudyMaterials();
    res.json(materials);
  });

  app.get("/api/study-materials/:id", async (req, res) => {
    const material = await storage.getStudyMaterial(parseInt(req.params.id));
    if (!material) {
      return res.status(404).send("Study material not found");
    }
    res.json(material);
  });

  // Questions
  app.get("/api/questions", async (req, res) => {
    const questions = await storage.getQuestions();
    res.json(questions);
  });

  app.get("/api/questions/category/:category", async (req, res) => {
    const questions = await storage.getQuestionsByCategory(req.params.category);
    res.json(questions);
  });

  // Progress
  app.get("/api/progress", async (req, res) => {
    if (!req.user) {
      return res.status(401).send("Not authenticated");
    }
    const progress = await storage.getUserProgress(req.user.id);
    res.json(progress);
  });

  app.post("/api/progress", async (req, res) => {
    if (!req.user) {
      return res.status(401).send("Not authenticated");
    }
    const validatedProgress = insertProgressSchema.parse(req.body);
    const progress = await storage.updateProgress({
      ...validatedProgress,
      userId: req.user.id
    });
    res.json(progress);
  });

  // Analytics routes
  app.get("/api/analytics/summary", async (req, res) => {
    if (!req.user) {
      return res.status(401).send("Not authenticated");
    }
    const summary = await storage.getUserAnalyticsSummary(req.user.id);
    res.json(summary);
  });

  app.get("/api/analytics/quiz-results", async (req, res) => {
    if (!req.user) {
      return res.status(401).send("Not authenticated");
    }
    const results = await storage.getQuizResults(req.user.id);
    res.json(results);
  });

  app.post("/api/analytics/quiz-results", async (req, res) => {
    if (!req.user) {
      return res.status(401).send("Not authenticated");
    }
    const result = insertQuizResultSchema.parse({
      ...req.body,
      userId: req.user.id
    });
    const savedResult = await storage.saveQuizResult(result);
    res.json(savedResult);
  });

  app.get("/api/analytics/viewing-stats/:tutorialId?", async (req, res) => {
    if (!req.user) {
      return res.status(401).send("Not authenticated");
    }
    const tutorialId = req.params.tutorialId ? parseInt(req.params.tutorialId) : undefined;
    const stats = await storage.getViewingStats(req.user.id, tutorialId);
    res.json(stats);
  });

  app.post("/api/analytics/viewing-stats", async (req, res) => {
    if (!req.user) {
      return res.status(401).send("Not authenticated");
    }
    const stats = insertViewingStatsSchema.parse({
      ...req.body,
      userId: req.user.id
    });
    const savedStats = await storage.updateViewingStats(stats);
    res.json(savedStats);
  });

  app.get("/api/analytics/study-stats/:materialId?", async (req, res) => {
    if (!req.user) {
      return res.status(401).send("Not authenticated");
    }
    const materialId = req.params.materialId ? parseInt(req.params.materialId) : undefined;
    const stats = await storage.getStudyStats(req.user.id, materialId);
    res.json(stats);
  });

  app.post("/api/analytics/study-stats", async (req, res) => {
    if (!req.user) {
      return res.status(401).send("Not authenticated");
    }
    const stats = insertStudyStatsSchema.parse({
      ...req.body,
      userId: req.user.id
    });
    const savedStats = await storage.updateStudyStats(stats);
    res.json(savedStats);
  });

  app.get("/api/analytics/achievements", async (req, res) => {
    if (!req.user) {
      return res.status(401).send("Not authenticated");
    }
    const achievements = await storage.getAchievements(req.user.id);
    res.json(achievements);
  });

  // Study Groups routes
  app.get("/api/study-groups", async (req, res) => {
    const category = req.query.category as string | undefined;
    const groups = await storage.getStudyGroups({ category });
    res.json(groups);
  });

  app.get("/api/study-groups/me", async (req, res) => {
    if (!req.user) return res.status(401).send("Not authenticated");
    const groups = await storage.getUserStudyGroups(req.user.id);
    res.json(groups);
  });

  app.get("/api/study-groups/:id", async (req, res) => {
    const group = await storage.getStudyGroup(parseInt(req.params.id));
    if (!group) return res.status(404).send("Study group not found");
    res.json(group);
  });

  app.post("/api/study-groups", async (req, res) => {
    if (!req.user) return res.status(401).send("Not authenticated");
    const groupData = insertStudyGroupSchema.parse({
      ...req.body,
      createdBy: req.user.id
    });
    const group = await storage.createStudyGroup(groupData);

    // Auto-add creator as admin
    await storage.addGroupMember({
      groupId: group.id,
      userId: req.user.id,
      role: "admin"
    });

    res.status(201).json(group);
  });

  app.patch("/api/study-groups/:id", async (req, res) => {
    if (!req.user) return res.status(401).send("Not authenticated");

    const groupId = parseInt(req.params.id);
    const group = await storage.getStudyGroup(groupId);
    if (!group) return res.status(404).send("Study group not found");

    // Check if user is admin
    const membership = await storage.getGroupMember(groupId, req.user.id);
    if (!membership || membership.role !== "admin") {
      return res.status(403).send("Not authorized");
    }

    const updatedGroup = await storage.updateStudyGroup(groupId, req.body);
    res.json(updatedGroup);
  });

  // Group Members routes
  app.get("/api/study-groups/:id/members", async (req, res) => {
    const members = await storage.getGroupMembers(parseInt(req.params.id));
    res.json(members);
  });

  app.post("/api/study-groups/:id/members", async (req, res) => {
    if (!req.user) return res.status(401).send("Not authenticated");

    const groupId = parseInt(req.params.id);
    const group = await storage.getStudyGroup(groupId);
    if (!group) return res.status(404).send("Study group not found");

    const existingMember = await storage.getGroupMember(groupId, req.user.id);
    if (existingMember) return res.status(400).send("Already a member");

    const memberData = insertGroupMemberSchema.parse({
      groupId,
      userId: req.user.id,
      role: "member"
    });

    const member = await storage.addGroupMember(memberData);
    res.status(201).json(member);
  });

  app.delete("/api/study-groups/:groupId/members/:userId", async (req, res) => {
    if (!req.user) return res.status(401).send("Not authenticated");

    const groupId = parseInt(req.params.groupId);
    const targetUserId = parseInt(req.params.userId);

    // Check if user is admin or removing themselves
    const membership = await storage.getGroupMember(groupId, req.user.id);
    if (!membership || (membership.role !== "admin" && req.user.id !== targetUserId)) {
      return res.status(403).send("Not authorized");
    }

    await storage.removeGroupMember(groupId, targetUserId);
    res.sendStatus(204);
  });

  // Group Discussions routes
  app.get("/api/study-groups/:id/discussions", async (req, res) => {
    const limit = req.query.limit ? parseInt(req.query.limit as string) : undefined;
    const discussions = await storage.getGroupDiscussions(
      parseInt(req.params.id),
      limit
    );
    res.json(discussions);
  });

  app.post("/api/study-groups/:id/discussions", async (req, res) => {
    if (!req.user) return res.status(401).send("Not authenticated");

    const groupId = parseInt(req.params.id);
    const membership = await storage.getGroupMember(groupId, req.user.id);
    if (!membership) return res.status(403).send("Not a member");

    const discussionData = insertGroupDiscussionSchema.parse({
      ...req.body,
      groupId,
      userId: req.user.id
    });

    const discussion = await storage.addGroupDiscussion(discussionData);
    res.status(201).json(discussion);
  });

  app.delete("/api/study-groups/:groupId/discussions/:discussionId", async (req, res) => {
    if (!req.user) return res.status(401).send("Not authenticated");

    const groupId = parseInt(req.params.groupId);
    const discussionId = parseInt(req.params.discussionId);

    // Check if user is admin or the author of the discussion
    const membership = await storage.getGroupMember(groupId, req.user.id);
    const discussion = await storage.getGroupDiscussions(groupId)
      .then(discussions => discussions.find(d => d.id === discussionId));

    if (!membership || (!discussion || (discussion.userId !== req.user.id && membership.role !== "admin"))) {
      return res.status(403).send("Not authorized");
    }

    await storage.deleteGroupDiscussion(discussionId);
    res.sendStatus(204);
  });

  const httpServer = createServer(app);
  return httpServer;
}