import { IStorage } from "./types";
import {
  User,
  InsertUser,
  Tutorial,
  StudyMaterial,
  Question,
  Progress,
  QuizResult,
  ViewingStat,
  StudyStat,
  Achievement,
  StudyGroup,
  GroupMember,
  GroupDiscussion
} from "@shared/schema";
import session from "express-session";
import createMemoryStore from "memorystore";

const MemoryStore = createMemoryStore(session);

export class MemStorage implements IStorage {
  private users: Map<number, User>;
  private tutorials: Map<number, Tutorial>;
  private studyMaterials: Map<number, StudyMaterial>;
  private questions: Map<number, Question>;
  private progress: Map<number, Progress>;
  private quizResults: Map<number, QuizResult>;
  private viewingStats: Map<number, ViewingStat>;
  private studyStats: Map<number, StudyStat>;
  private achievements: Map<number, Achievement>;
  private studyGroups: Map<number, StudyGroup>;
  private groupMembers: Map<number, GroupMember>;
  private groupDiscussions: Map<number, GroupDiscussion>;

  currentId: number;
  sessionStore: session.Store;

  constructor() {
    this.users = new Map();
    this.tutorials = new Map();
    this.studyMaterials = new Map();
    this.questions = new Map();
    this.progress = new Map();
    this.quizResults = new Map();
    this.viewingStats = new Map();
    this.studyStats = new Map();
    this.achievements = new Map();
    this.studyGroups = new Map();
    this.groupMembers = new Map();
    this.groupDiscussions = new Map();
    this.currentId = 1;
    this.sessionStore = new MemoryStore({
      checkPeriod: 86400000 // 24h
    });
  }

  // User methods
  async getUser(id: number): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(
      (user) => user.username === username
    );
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const id = this.currentId++;
    const user: User = {
      ...insertUser,
      id,
      role: "student",
      createdAt: new Date()
    };
    this.users.set(id, user);
    return user;
  }

  // Tutorial methods
  async getTutorials(): Promise<Tutorial[]> {
    return Array.from(this.tutorials.values());
  }

  async getTutorial(id: number): Promise<Tutorial | undefined> {
    return this.tutorials.get(id);
  }

  async getTutorialsByCategory(category: string): Promise<Tutorial[]> {
    return Array.from(this.tutorials.values())
      .filter(tutorial => tutorial.category === category);
  }

  // Study materials methods
  async getStudyMaterials(): Promise<StudyMaterial[]> {
    return Array.from(this.studyMaterials.values());
  }

  async getStudyMaterial(id: number): Promise<StudyMaterial | undefined> {
    return this.studyMaterials.get(id);
  }

  async createStudyMaterial(material: Omit<StudyMaterial, "id">): Promise<StudyMaterial> {
    const id = this.currentId++;
    const newMaterial = { ...material, id };
    this.studyMaterials.set(id, newMaterial);
    return newMaterial;
  }

  // Question methods
  async getQuestions(): Promise<Question[]> {
    return Array.from(this.questions.values());
  }

  async getQuestionsByCategory(category: string): Promise<Question[]> {
    return Array.from(this.questions.values())
      .filter(q => q.category === category);
  }

  // Progress methods
  async getUserProgress(userId: number): Promise<Progress[]> {
    return Array.from(this.progress.values())
      .filter(p => p.userId === userId);
  }

  async updateProgress(progress: Progress): Promise<Progress> {
    this.progress.set(progress.id, progress);
    return progress;
  }

  // Analytics methods
  async getQuizResults(userId: number): Promise<QuizResult[]> {
    return Array.from(this.quizResults.values())
      .filter(result => result.userId === userId);
  }

  async saveQuizResult(result: Omit<QuizResult, "id">): Promise<QuizResult> {
    const id = this.currentId++;
    const newResult = { ...result, id };
    this.quizResults.set(id, newResult);
    return newResult;
  }

  async getViewingStats(userId: number, tutorialId?: number): Promise<ViewingStat[]> {
    return Array.from(this.viewingStats.values())
      .filter(stat => stat.userId === userId &&
        (!tutorialId || stat.tutorialId === tutorialId));
  }

  async updateViewingStats(stats: Omit<ViewingStat, "id">): Promise<ViewingStat> {
    const id = this.currentId++;
    const newStats = { ...stats, id };
    this.viewingStats.set(id, newStats);
    return newStats;
  }

  async getStudyStats(userId: number, materialId?: number): Promise<StudyStat[]> {
    return Array.from(this.studyStats.values())
      .filter(stat => stat.userId === userId &&
        (!materialId || stat.materialId === materialId));
  }

  async updateStudyStats(stats: Omit<StudyStat, "id">): Promise<StudyStat> {
    const id = this.currentId++;
    const newStats = { ...stats, id };
    this.studyStats.set(id, newStats);
    return newStats;
  }

  async getAchievements(userId: number): Promise<Achievement[]> {
    return Array.from(this.achievements.values())
      .filter(achievement => achievement.userId === userId);
  }

  async addAchievement(achievement: Omit<Achievement, "id">): Promise<Achievement> {
    const id = this.currentId++;
    const newAchievement = { ...achievement, id };
    this.achievements.set(id, newAchievement);
    return newAchievement;
  }

  async getUserAnalyticsSummary(userId: number): Promise<{
    totalQuizzesTaken: number;
    averageScore: number;
    totalWatchTime: number;
    completedTutorials: number;
    achievementsCount: number;
  }> {
    const quizResults = await this.getQuizResults(userId);
    const viewingStats = await this.getViewingStats(userId);
    const achievements = await this.getAchievements(userId);
    const completedTutorials = (await this.getUserProgress(userId))
      .filter(p => p.completed).length;

    const totalScore = quizResults.reduce((sum, result) => sum + result.score, 0);
    const totalWatchTime = viewingStats.reduce((sum, stat) => sum + stat.watchTime, 0);

    return {
      totalQuizzesTaken: quizResults.length,
      averageScore: quizResults.length > 0 ? totalScore / quizResults.length : 0,
      totalWatchTime,
      completedTutorials,
      achievementsCount: achievements.length,
    };
  }

  // Study Groups methods
  async createStudyGroup(group: Omit<StudyGroup, "id">): Promise<StudyGroup> {
    const id = this.currentId++;
    const newGroup = { ...group, id };
    this.studyGroups.set(id, newGroup);
    return newGroup;
  }

  async getStudyGroup(id: number): Promise<StudyGroup | undefined> {
    return this.studyGroups.get(id);
  }

  async getStudyGroups(filter?: { category?: string }): Promise<StudyGroup[]> {
    let groups = Array.from(this.studyGroups.values());
    if (filter?.category) {
      groups = groups.filter(group => group.category === filter.category);
    }
    return groups;
  }

  async getUserStudyGroups(userId: number): Promise<StudyGroup[]> {
    const memberGroups = Array.from(this.groupMembers.values())
      .filter(member => member.userId === userId)
      .map(member => member.groupId);
    return Array.from(this.studyGroups.values())
      .filter(group => memberGroups.includes(group.id));
  }

  async updateStudyGroup(id: number, data: Partial<StudyGroup>): Promise<StudyGroup> {
    const group = await this.getStudyGroup(id);
    if (!group) throw new Error("Study group not found");
    const updatedGroup = { ...group, ...data };
    this.studyGroups.set(id, updatedGroup);
    return updatedGroup;
  }

  // Group Members methods
  async addGroupMember(member: Omit<GroupMember, "id">): Promise<GroupMember> {
    const id = this.currentId++;
    const newMember = { ...member, id };
    this.groupMembers.set(id, newMember);
    return newMember;
  }

  async removeGroupMember(groupId: number, userId: number): Promise<void> {
    const member = Array.from(this.groupMembers.values())
      .find(m => m.groupId === groupId && m.userId === userId);
    if (member) {
      this.groupMembers.delete(member.id);
    }
  }

  async getGroupMembers(groupId: number): Promise<GroupMember[]> {
    return Array.from(this.groupMembers.values())
      .filter(member => member.groupId === groupId);
  }

  async getGroupMember(groupId: number, userId: number): Promise<GroupMember | undefined> {
    return Array.from(this.groupMembers.values())
      .find(member => member.groupId === groupId && member.userId === userId);
  }

  // Group Discussions methods
  async addGroupDiscussion(discussion: Omit<GroupDiscussion, "id">): Promise<GroupDiscussion> {
    const id = this.currentId++;
    const newDiscussion = { ...discussion, id };
    this.groupDiscussions.set(id, newDiscussion);
    return newDiscussion;
  }

  async getGroupDiscussions(groupId: number, limit?: number): Promise<GroupDiscussion[]> {
    let discussions = Array.from(this.groupDiscussions.values())
      .filter(discussion => discussion.groupId === groupId)
      .sort((a, b) => b.createdAt.getTime() - a.createdAt.getTime());
    if (limit) {
      discussions = discussions.slice(0, limit);
    }
    return discussions;
  }

  async deleteGroupDiscussion(id: number): Promise<void> {
    this.groupDiscussions.delete(id);
  }
}

export const storage = new MemStorage();