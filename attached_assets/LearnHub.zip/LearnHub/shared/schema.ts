import { pgTable, text, serial, integer, boolean, timestamp, json } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
  name: text("name").notNull(),
  email: text("email").notNull(),
  role: text("role").notNull().default("student"),
  createdAt: timestamp("created_at").defaultNow()
});

export const tutorials = pgTable("tutorials", {
  id: serial("id").primaryKey(),
  title: text("title").notNull(),
  description: text("description").notNull(),
  videoUrl: text("video_url").notNull(),
  thumbnailUrl: text("thumbnail_url").notNull(),
  category: text("category").notNull(),
  duration: integer("duration").notNull(),
  instructor: text("instructor").notNull(),
  createdAt: timestamp("created_at").defaultNow()
});

export const studyMaterials = pgTable("study_materials", {
  id: serial("id").primaryKey(),
  title: text("title").notNull(),
  content: text("content").notNull(),
  category: text("category").notNull(),
  createdBy: integer("created_by").notNull(),
  createdAt: timestamp("created_at").defaultNow()
});

export const questions = pgTable("questions", {
  id: serial("id").primaryKey(),
  question: text("question").notNull(),
  options: json("options").notNull(),
  correctAnswer: text("correct_answer").notNull(),
  explanation: text("explanation").notNull(),
  category: text("category").notNull(),
  difficulty: text("difficulty").notNull(),
  createdAt: timestamp("created_at").defaultNow()
});

export const userProgress = pgTable("user_progress", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull(),
  tutorialId: integer("tutorial_id").notNull(),
  completed: boolean("completed").notNull().default(false),
  progress: integer("progress").notNull().default(0),
  lastAccessed: timestamp("last_accessed").defaultNow()
});

export const insertUserSchema = createInsertSchema(users).pick({
  username: true,
  password: true,
  name: true,
  email: true
});

export const insertTutorialSchema = createInsertSchema(tutorials);
export const insertStudyMaterialSchema = createInsertSchema(studyMaterials);
export const insertQuestionSchema = createInsertSchema(questions);
export const insertProgressSchema = createInsertSchema(userProgress);

export type InsertUser = z.infer<typeof insertUserSchema>;
export type User = typeof users.$inferSelect;
export type Tutorial = typeof tutorials.$inferSelect;
export type StudyMaterial = typeof studyMaterials.$inferSelect;
export type Question = typeof questions.$inferSelect;
export type Progress = typeof userProgress.$inferSelect;

export const quizResults = pgTable("quiz_results", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull(),
  quizId: integer("quiz_id").notNull(),
  score: integer("score").notNull(),
  timeSpent: integer("time_spent").notNull(), // in seconds
  completedAt: timestamp("completed_at").defaultNow()
});

export const viewingStats = pgTable("viewing_stats", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull(),
  tutorialId: integer("tutorial_id").notNull(),
  watchTime: integer("watch_time").notNull(), // in seconds
  lastPosition: integer("last_position").notNull(), // video position in seconds
  completionRate: integer("completion_rate").notNull(), // percentage
  updatedAt: timestamp("updated_at").defaultNow()
});

export const studyStats = pgTable("study_stats", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull(),
  materialId: integer("material_id").notNull(),
  timeSpent: integer("time_spent").notNull(), // in seconds
  lastAccessed: timestamp("last_accessed").defaultNow()
});

export const achievements = pgTable("achievements", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull(),
  type: text("type").notNull(), // e.g., "quiz_master", "video_complete", etc.
  title: text("title").notNull(),
  description: text("description").notNull(),
  metadata: json("metadata"), // additional achievement-specific data
  unlockedAt: timestamp("unlocked_at").defaultNow()
});

// Add new insert schemas
export const insertQuizResultSchema = createInsertSchema(quizResults);
export const insertViewingStatsSchema = createInsertSchema(viewingStats);
export const insertStudyStatsSchema = createInsertSchema(studyStats);
export const insertAchievementSchema = createInsertSchema(achievements);

// Add new types
export type QuizResult = typeof quizResults.$inferSelect;
export type ViewingStat = typeof viewingStats.$inferSelect;
export type StudyStat = typeof studyStats.$inferSelect;
export type Achievement = typeof achievements.$inferSelect;


export const studyGroups = pgTable("study_groups", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  description: text("description").notNull(),
  createdBy: integer("created_by").notNull(),
  category: text("category").notNull(),
  isPrivate: boolean("is_private").notNull().default(false),
  maxMembers: integer("max_members").notNull().default(50),
  createdAt: timestamp("created_at").defaultNow()
});

export const groupMembers = pgTable("group_members", {
  id: serial("id").primaryKey(),
  groupId: integer("group_id").notNull(),
  userId: integer("user_id").notNull(),
  role: text("role").notNull().default("member"), // "admin" or "member"
  joinedAt: timestamp("joined_at").defaultNow()
});

export const groupDiscussions = pgTable("group_discussions", {
  id: serial("id").primaryKey(),
  groupId: integer("group_id").notNull(),
  userId: integer("user_id").notNull(),
  content: text("content").notNull(),
  attachmentUrl: text("attachment_url"),
  createdAt: timestamp("created_at").defaultNow()
});

// Add new insert schemas
export const insertStudyGroupSchema = createInsertSchema(studyGroups);
export const insertGroupMemberSchema = createInsertSchema(groupMembers);
export const insertGroupDiscussionSchema = createInsertSchema(groupDiscussions);

// Add new types
export type StudyGroup = typeof studyGroups.$inferSelect;
export type GroupMember = typeof groupMembers.$inferSelect;
export type GroupDiscussion = typeof groupDiscussions.$inferSelect;